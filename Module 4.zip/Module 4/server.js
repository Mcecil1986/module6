import { readFile } from 'fs';
import { createServer } from 'http';
import { once } from 'lodash';

const server = createServer((req,res) => {
  //lodash
  const num=random(0,20);
  console.log(num);

  const greet = once(() => {
    console.log('hello');
});

    greet();
    greet();

    // set header content type
    res.setHeader('Content-Type', 'text/html');

    let path='./views/';
    switch(req.url){
        case'/':
            path += 'index.html';
            res.statusCode = 200;
            break;
        case '/about':
            path += 'about.html';
            res.statusCode = 200;
            break;
        case '/about-me':
                res.statusCode = 301;
                res.setHeader('Location','/about');
                res.destroyed();
                break;
        default:
            path+= '404.html';
            res.statusCode = 404;
            break;
    }

    //send html file 
    readFile(path,(error, data) => {
        if (err) {
            console.log(err);
            res.end();
        } else{
           // res.write(data);
            
            res.end();
        }
    })
});
    server.listen(3000, 'localhost', () => {
    console.log ('listening for request on port 3000');
});
